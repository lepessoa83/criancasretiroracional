Cadastro Crianças — pacote pronto for GitHub Pages

Files included:
- index.html
- cadastro.html (password: Retiro2025)
- style.css
- script.js
- cadastros.csv (63 entries)

Your Apps Script endpoint (already deployed):
https://script.google.com/macros/s/AKfycbzrHI6Zp7tTkI8VKalbIG8rINhES9dxBQr591q6ZKJD1skbiHLoYsGv8dY96WZMawqJsQ/exec

How to publish:
1. Create a GitHub repo and upload files.
2. Enable Pages on the repository.
3. Visit the site.

Test:
- Open cadastro.html, enter password Retiro2025, create a record with photo from device.
- It will POST to your Apps Script and also save locally if offline.
